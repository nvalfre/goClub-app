bool notNull(Object object){
  return !isNull(object);
}

bool isNull(Object object){
  return object == null;
}
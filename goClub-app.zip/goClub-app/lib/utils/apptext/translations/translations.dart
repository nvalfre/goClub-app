
import 'i18n/i18n_es.dart';

const Map<String, dynamic> I18N = {
  "es" : ES
};
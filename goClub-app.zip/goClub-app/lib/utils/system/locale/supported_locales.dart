import 'package:flutter/material.dart';

const Locale SPANISH = const Locale("es");